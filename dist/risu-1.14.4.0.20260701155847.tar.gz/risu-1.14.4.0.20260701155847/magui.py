#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (C) 2017
# Copyright (C) 2017, 2018, 2020
import sys

from maguiclient.magui import main

if __name__ == "__main__":
    sys.exit(main())
