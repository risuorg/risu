#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Description: Multiple Analysis Generic Unifier and Interpreter aka Magui
#              This program processes several snapshoot/sosreport files
#              and processes risu output for combined issues via plugins
#              that search for specific plugin and data
#
# Copyright (C) 2017, 2018
# Copyright (C) 2018
# Copyright (C) 2017-2021, 2023, 2024, 2026
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
from __future__ import print_function

import argparse
import copy
import gettext
import glob
import hashlib
import logging
import os.path
import shutil
import sys
import time

sys.path.append(os.path.abspath(os.path.dirname(__file__) + "/" + "../"))

from maguiclient import autogroup as autogroup_module
from maguiclient import client as magui_client
from risuclient import shell as risu

LOG = logging.getLogger("magui")

# Where are we?
maguidir = os.path.abspath(os.path.dirname(__file__))
localedir = os.path.join(risu.risudir, "locale")

global PluginsFolder
PluginsFolder = os.path.join(maguidir, "plugins")

global MaguiHooksFolder
MaguiHooksFolder = os.path.join(maguidir, "hooks")

global plugins
plugins = []
global plugtriggers
plugtriggers = {}
global maguihooks
maguihooks = []

trad = gettext.translation("risu", localedir, fallback=True)

try:
    _ = trad.ugettext
except AttributeError:
    _ = trad.gettext


def show_logo():
    """
    Prints Magui Logo
    :return:
    """

    logo = (
        r"    _    ",
        r"  _( )_  Magui:",
        r" (_(ø)_) ",
        r"  /(_)   Multiple Analisis Generic Unifier and Interpreter",
        r" \|      ",
        r"  |/     ",
        r"",
    )
    print("\n".join(logo))


def parse_args():
    """
    Parses arguments on commandline
    :return: parsed arguments
    """
    description = _(
        "Processes several generic archives/sosreports scripts in a uniform way, to interpret status that depend on several systems data"
    )

    # Option parsing
    p = argparse.ArgumentParser("magui.py [arguments]", description=description)
    p.add_argument(
        "-d",
        "--loglevel",
        help=_("Set log level"),
        default="info",
        type=lambda x: x.upper(),
        choices=["INFO", "DEBUG", "WARNING", "ERROR", "CRITICAL"],
    )
    p.add_argument(
        "--list-plugins",
        action="store_true",
        help=_("Print a list of discovered Magui plugins and exit"),
    )
    p.add_argument(
        "--description",
        action="store_true",
        help=_("With list-plugins, also outputs plugin description"),
    )
    p.add_argument(
        "-m",
        "--mpath",
        dest="mpath",
        help=_("Set path for Magui plugin location if not default"),
        action="append",
    )
    p.add_argument(
        "--output",
        "-o",
        metavar="FILENAME",
        help=_("Write results to JSON file FILENAME"),
        default="magui.json",
    )
    p.add_argument(
        "--run",
        "-r",
        action="store_true",
        help=_("Force run of risu instead of reading existing 'risu.json'"),
    )
    p.add_argument(
        "--hosts",
        metavar="hosts",
        help=_("Gather data via ansible from remote hosts to process."),
    )

    p.add_argument(
        "--max-hosts",
        default=10,
        metavar="max-hosts",
        help=_("Define the number of maximum simultaneous hosts checks"),
    )

    p.add_argument(
        "--extraplugintree",
        default=False,
        help=_("Adds extra plugin tree structure for plugins"),
        metavar="extraplugintree",
    )

    g = p.add_argument_group("Filtering options")
    g.add_argument("-q", "--quiet", help=_("Enable quiet mode"), action="store_true")
    g.add_argument(
        "-i",
        "--include",
        metavar="SUBSTRING",
        help=_("Only include plugins that contain substring"),
        default=[],
        action="append",
    )
    g.add_argument(
        "-x",
        "--exclude",
        metavar="SUBSTRING",
        help=_("Exclude plugins that contain substring"),
        default=[],
        action="append",
    )
    g.add_argument(
        "-p",
        "--prio",
        metavar="[0-1000]",
        type=int,
        choices=range(1001),
        help=_("Only include plugins are equal or above specified prio"),
        default=0,
    )
    g.add_argument(
        "-mf",
        "--mfilter",
        dest="mfilter",
        help=_("Only include Magui plugins that contains in full path that substring"),
        default=[],
        action="append",
    )
    g.add_argument(
        "--anon", dest="anon", action="store_true", help=_("Anonymize output")
    )
    g.add_argument("--lang", help=_("Define locale to use"), default="en_US")
    g.add_argument(
        "--call-home",
        default=False,
        help=_("Server URI to HTTP-post upload generated risu.json for metrics"),
        metavar="serveruri",
    )

    p.add_argument("sosreports", nargs="*")

    return p.parse_args()


def commonpath(folders):
    """
    Checks the minimum common path in provided paths
    :param folders: path array for folder
    :return: string: common path
    """

    code = ""
    if folders:
        try:
            # Python 3.x
            code = os.path.commonpath(folders)
        except AttributeError:
            # Python 2.x
            code = os.path.commonprefix(folders).rsplit("/", 1)[0]

    return code


def callrisu(path=False, plugins=False, forcerun=False, include=None, exclude=None):
    """
    Do actual execution of risu against data
    :param exclude: keywords to exclude
    :param include: keywords to include
    :param forcerun: Forces execution of risu analysis (ignoring saved data in risu.json)
    :param path: sosreport path
    :param plugins: plugins enabled as provided to risu
    :return: dict with results

    NOTE: This function now delegates to MaguiClient for better maintainability.
    Kept here for backward compatibility.
    """

    # Create temporary client for backward compatibility
    class TempOptions(object):
        def __init__(self):
            self.run = forcerun
            self.include = include
            self.exclude = exclude
            self.quiet = True

    client = magui_client.MaguiClient(TempOptions())
    return client.call_risu(path, plugins)


def findtarget(data):
    """
    Sorts autogroup to find next target to reduce memory usage and data reuse
    :param data: autogroup dictionary
    :return: array made of target, data and elem to del (if any)

    NOTE: This function now delegates to the AutoGroupManager class in
    maguiclient.autogroup for better maintainability. Kept here for
    backward compatibility.
    """
    return autogroup_module.findtarget(data)


def domagui(sosreports, risuplugins, options=False, grouped={}, runhooks=True):
    """
    Do actual execution against sosreports
    :return: dict of result
    """

    if grouped != {}:
        # Cleanup grouped for sosreports we're not interested at all
        cleansosreports = []

        for plugin in grouped:
            # Walk plugins
            for sosreport in grouped[plugin]["sosreport"]:
                # Walk sosreports for plugin
                if sosreport not in sosreports:
                    # Add sosreport to cleanup list
                    cleansosreports.append(sosreport)

        for sosreport in sorted(set(cleansosreports)):
            for plugin in grouped:
                if sosreport in grouped[plugin]["sosreport"]:
                    del grouped[plugin]["sosreport"][sosreport]
    else:
        # Check if we've been provided options
        if options:
            forcerun = options.run
            citinclude = options.include
            citexclude = options.exclude
            hosts = options.hosts
        else:
            forcerun = False
            citinclude = None
            citexclude = None
            hosts = False

        # Grab data from risu for the sosreports provided
        result = {}

        for sosreport in sosreports:
            result[sosreport] = callrisu(
                path=os.path.abspath(sosreport),
                plugins=risuplugins,
                forcerun=forcerun,
                include=citinclude,
                exclude=citexclude,
            )

        # Sanity check in case we do need to force run because of inconsistencies between saved data
        if not forcerun:
            # Prefill all plugins
            plugins = []
            for sosreport in sosreports:
                for plugin in result[sosreport]:
                    plugins.append(plugin)

            plugins = sorted(set(plugins))

            rerun = False
            # Check all sosreports for data for all plugins
            for sosreport in sosreports:
                for plugin in plugins:
                    # Skip composed plugins as they will cause rerun
                    if "-" not in plugin:
                        try:
                            result[sosreport][plugin]["result"]
                        except (KeyError, TypeError):
                            rerun = True

                # If we were running against a folder with just json, cancel rerun as it will fail
                if rerun:
                    try:
                        access = os.access(
                            os.path.join(sosreport, "version.txt"), os.R_OK
                        )
                    except (OSError, TypeError):
                        access = False

                    if not access:
                        # We're running against a folder that misses version.txt, so probably just folder with json, skip rerun
                        rerun = False

                # Forcing rerun but not if we've specified ansible hosts
                if rerun and not hosts:
                    LOG.debug(
                        "Forcing rerun of risu for %s because of missing %s"
                        % (sosreport, plugin)
                    )
                    # Sosreport contains non uniform data, rerun
                    result[sosreport] = callrisu(
                        path=os.path.abspath(sosreport),
                        plugins=risuplugins,
                        forcerun=True,
                    )

        # Precreate multidimensional array
        grouped = {}
        for sosreport in sosreports:
            plugins = []
            for plugin in result[sosreport]:
                plugins.append(plugin)
                grouped[plugin] = {}
                grouped[plugin]["sosreport"] = {}

        # Fill the data
        for sosreport in sosreports:
            for plugin in result[sosreport]:
                grouped[plugin]["sosreport"][sosreport] = result[sosreport][plugin][
                    "result"
                ]
                for element in result[sosreport][plugin]:
                    # Some of the elements are not useful as they are sosreport specific, so we do skip them completely
                    # In this approach we don't need to update this code each time the plugin exports new metadata
                    if element not in ["time", "result"]:
                        grouped[plugin][element] = result[sosreport][plugin][element]

    if runhooks:
        # Run the hook processing hooks on the results
        for maguihook in risu.initPymodules(
            extensions=risu.getPymodules(options=options, folders=[MaguiHooksFolder])
        )[0]:
            LOG.debug("Running hook: %s" % maguihook.__name__.split(".")[-1])
            newresults = maguihook.run(data=copy.deepcopy(grouped))
            if newresults:
                grouped = newresults

    # We've now a matrix of grouped[plugin][sosreport] and then [text] [out] [err] [rc]
    return grouped


def filterresults(data, triggers=[]):
    """
    Filters results for only the data that plugin will use
    :param data: full set of data
    :param triggers: set of triggers (plugin ID's) to match
    :return: filtered data of only those plugins

    NOTE: This function now delegates to MaguiClient for better maintainability.
    Kept here for backward compatibility.
    """
    client = magui_client.MaguiClient()
    return client.filter_results(data, triggers)


def autogroups(autodata):
    """
    Based on metadata-outputs plugin generate possible groups for sosreport combination
    :param autodata: metadata-outputs results
    :return: dict of groups and members

    NOTE: This function now delegates to the AutoGroupManager class in
    maguiclient.autogroup for better maintainability and testability.
    Kept here for backward compatibility.
    """
    return autogroup_module.autogroups(autodata)


def main():
    """
    Main code stub
    """

    options = parse_args()

    # Configure ENV language before anything else
    os.environ["LANG"] = "%s" % options.lang

    # Reinstall language in case it has changed
    trad = gettext.translation(
        "risu", localedir, fallback=True, languages=[options.lang]
    )

    try:
        _ = trad.ugettext
    except AttributeError:
        _ = trad.gettext

    # Configure logging
    logging.basicConfig(level=options.loglevel)

    if not options.quiet:
        show_logo()

    # Each argument in sosreport is a sosreport

    magplugs, magtriggers = risu.initPymodules(
        extensions=risu.getPymodules(options=options, folders=[PluginsFolder])
    )

    if options.list_plugins:
        for plugin in magplugs:
            print("-", plugin.__name__.split(".")[-1])
            if options.description:
                desc = plugin.help()
                if desc:
                    print(risu.indent(text=desc, amount=4))
        return

    # Prefill enabled risu plugins from args
    if not risu.extensions:
        extensions = risu.initPymodules()[0]
    else:
        extensions = risu.extensions

    # Grab the data
    sosreports = options.sosreports

    # If we've provided a hosts file, use ansible to grab the data from them
    if options.hosts:
        ansible = risu.which("ansible-playbook")
        if not ansible:
            LOG.err(_("No ansible-playbook support found, skipping"))
        else:
            LOG.info("Grabbing data from remote hosts with Ansible")
            # Grab data from ansible hosts

            # Disable Ansible retry files creation:
            os.environ["ANSIBLE_RETRY_FILES_ENABLED"] = "0"

            if options.loglevel == "DEBUG":
                # Keep ansible remote files for debug
                os.environ["ANSIBLE_KEEP_REMOTE_FILES"] = "1"

            command = "%s -i %s %s" % (
                ansible,
                options.hosts,
                os.path.join(maguidir, "remote.yml"),
            )

            LOG.debug("Running: %s with 600 seconds timeout" % command)
            risu.execonshell(filename=command, timeout=600)

            # Now check the hosts we got logs from:
            hosts = risu.findplugins(
                folders=glob.glob("/tmp/risu/hostrun/*"),  # nosec B108
                executables=False,
                fileextension=".json",
            )
            for host in hosts:
                sosreports.append(os.path.dirname(host["plugin"]))

    # Get all data from hosts for all plugins, etc
    if options.output:
        dooutput = options.output
    else:
        dooutput = False

    if len(sosreports) > int(options.max_hosts):
        print("Maximum number of sosreports provided, exiting")
        sys.exit(0)

    risuplugins = []
    # Prefill with all available plugins and the ones we want to filter for
    for extension in extensions:
        risuplugins.extend(extension.listplugins())

    global allplugins
    allplugins = risuplugins

    # By default, flatten plugin list for all extensions
    newplugins = []
    for each in risuplugins:
        newplugins.extend(each)

    risuplugins = newplugins

    def runmaguiandplugs(
        sosreports,
        risuplugins,
        filename=dooutput,
        extranames=None,
        serveruri=False,
        onlysave=False,
        result=None,
        anon=False,
        grouped={},
    ):
        """
        Runs magui and magui plugins
        :param grouped: Grouped results from sosreports to speedup processing (domagui)
        :param anon: anonymize results on execution
        :param serveruri: Server uri to POST the analysis
        :param sosreports: sosreports to process
        :param risuplugins: risuplugins to run
        :param filename: filename to save to
        :param extranames: additional filenames used
        :param onlysave: Bool: Defines if we just want to save results
        :param result: Results to write to disk
        :return: results of execution
        """

        start_time = time.time()
        if not onlysave and not result:
            # Run with all plugins so that we get all data back
            grouped = domagui(
                sosreports=sosreports, risuplugins=risuplugins, grouped=grouped
            )

            # Run Magui plugins
            result = []
            for plugin in magplugs:
                plugstart_time = time.time()
                # Get output from plugin
                data = filterresults(
                    data=grouped, triggers=magtriggers[plugin.__name__.split(".")[-1]]
                )
                returncode, out, err = plugin.run(data=data, quiet=options.quiet)
                updates = {"rc": returncode, "out": out, "err": err}

                subcategory = os.path.split(plugin.__file__)[0].replace(
                    os.path.join(maguidir, "plugins", ""), ""
                )

                if subcategory:
                    if len(os.path.normpath(subcategory).split(os.sep)) > 1:
                        category = os.path.normpath(subcategory).split(os.sep)[0]
                    else:
                        category = subcategory
                        subcategory = ""
                else:
                    category = ""

                mydata = {
                    "plugin": plugin.__name__.split(".")[-1],
                    "name": "magui: %s"
                    % os.path.basename(plugin.__name__.split(".")[-1]),
                    "id": hashlib.sha512(
                        plugin.__file__.replace(maguidir, "").encode("UTF-8")
                    ).hexdigest(),
                    "description": plugin.help(),
                    "long_name": plugin.help(),
                    "result": updates,
                    "time": time.time() - plugstart_time,
                    "category": category,
                    "subcategory": subcategory,
                }

                result.append(mydata)
        if filename:
            branding = _("                                                  ")
            risu.write_results(
                results=result,
                filename=filename,
                source="magui",
                path=sosreports,
                time=time.time() - start_time,
                branding=branding,
                web=True,
                extranames=extranames,
                serveruri=serveruri,
                anon=anon,
            )

        return result, grouped

    print(_("\nStarting check updates and comparison"))

    metadataplugins = []
    for plugin in risuplugins:
        if plugin["backend"] == "metadata":
            metadataplugins.append(plugin)

    # Prepare metadata execution to find groups
    results, grouped = runmaguiandplugs(
        sosreports=sosreports,
        risuplugins=metadataplugins,
        filename=options.output,
        serveruri=options.call_home,
    )

    # Now we've Magui saved for the whole execution provided in 'results' var

    # Start working on autogroups
    autodata = ""

    for result in results:
        if result["plugin"] == "metadata-outputs":
            autodata = result["result"]["err"]

    print(_("\nGenerating autogroups:\n"))

    groups = autogroups(autodata)
    print(groups)
    processedgroups = {}

    # TODO(iranzo): Review this
    # This code was used to provide a field in json for risu.html to get
    # other groups in dropdown, but is not in use so commenting meanwhile

    filenames = []

    # loop over filenames first so that full results are saved and freed from memory
    for group in groups:
        basefilename = os.path.splitext(options.output)
        filename = basefilename[0] + "-" + group + basefilename[1]
        runautogroup = True
        for progroup in processedgroups:
            if sorted(set(groups[group])) == sorted(set(processedgroups[progroup])):
                runautogroup = False
                runautofile = progroup
        if runautogroup:
            # Analysis will be generated
            filenames.append(filename)

    print("\nRunning full comparison:... %s" % options.output)

    # Run full (not only metadata plugins) so that we've the data stored and save filenames in magui.json
    results, grouped = runmaguiandplugs(
        sosreports=sosreports,
        risuplugins=risuplugins,
        extranames=filenames,
        filename=options.output,
        serveruri=options.call_home,
    )

    # Here 'grouped' obtained from above contains the full set of data

    # Results stored, removing variable to free up memory
    del results

    # reset list of processed groups

    # while len(data) != 0:
    #     print "loop: ", loop
    #     loop = loop +1
    #     target, data, todel = findtarget(data)

    processedgroups = {}
    basefilename = os.path.splitext(options.output)

    while len(groups) != 0:
        target, newgroups, todel = findtarget(groups)
        if target and target != "":
            group = target
            filename = basefilename[0] + "-" + group + basefilename[1]
            print(_("\nRunning for group: %s" % filename))
            runautogroup = True

            for progroup in processedgroups:
                if groups[target] == processedgroups[progroup]:
                    runautogroup = False
                    runautofile = progroup

            if runautogroup:
                # Analysis was missing for this group, run it
                # pass grouped as 'dict' to avoid mutable
                newgrouped = copy.deepcopy(grouped)
                runmaguiandplugs(
                    sosreports=groups[target],
                    risuplugins=risuplugins,
                    filename=filename,
                    extranames=filenames,
                    anon=options.anon,
                    grouped=newgrouped,
                )
            else:
                # Copy file instead of run as it was already existing
                LOG.debug("Copying old file from %s to %s" % (runautofile, filename))
                shutil.copyfile(runautofile, filename)

            processedgroups[filename] = groups[target]

            if todel:
                # We can remove a sosreport from the dataset
                for plugin in grouped:
                    if todel in grouped[plugin]["sosreport"]:
                        del grouped[plugin]["sosreport"][todel]

            del newgroups[target]
            # Put remaining groups to work
            groups = dict(newgroups)

    del groups
    del processedgroups

    print(_("\nFinished autogroup generation."))


if __name__ == "__main__":
    main()
