#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (C) 2021
import sys

from risuclient.shell import main

if __name__ == "__main__":
    sys.exit(main())
