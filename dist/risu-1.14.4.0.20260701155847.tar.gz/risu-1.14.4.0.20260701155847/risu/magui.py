#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (C) 2017
# Copyright (C) 2017-2022
import os
import sys


def main(args=None):
    """The main routine."""
    if args is None:
        args = " ".join(sys.argv[1:])
    risudir = (
        "/".join(os.path.abspath(os.path.dirname(__file__)).split("/")[:-1])
        + "/magui.py"
    )
    os.system(risudir + " " + args)


if __name__ == "__main__":
    main()
